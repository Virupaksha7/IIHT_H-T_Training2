package com.cogjava.main;

import com.cogjava.tweetapp.UsersRegister;

public class Main {

	public static void main(String[] args) {
		
		try {

			UsersRegister userRegister = new UsersRegister();
			userRegister.addUserData();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
