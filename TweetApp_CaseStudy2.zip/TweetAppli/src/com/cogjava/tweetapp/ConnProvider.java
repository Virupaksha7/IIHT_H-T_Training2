package com.cogjava.tweetapp;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnProvider {

	static Connection con;

	public static Connection createC() {
		try {
			// Class.forName("com.mysql.jdbc.driver");

			String user = "root";
			String password = "root";

			String url = "jdbc:mysql://localhost:3306/cogjava";

			con = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
	}
}