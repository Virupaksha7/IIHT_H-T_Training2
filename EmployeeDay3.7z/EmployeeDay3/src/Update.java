import java.sql.*;
import java.util.Scanner;

public class Update {

	static final String D_URL="jdbc:mysql://localhost:3306/democog";
	static final String USER="root";
	static final String PASS="root";
	static final String QUERY="update employee set emp_name =? where emp_id=?;";
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Connection con =DriverManager.getConnection(D_URL, USER, PASS);
				PreparedStatement ps=con.prepareStatement(QUERY);){
			
			Scanner s =new Scanner(System.in);
			
			System.out.println("enter employee emp_id");
			int emp_id =s.nextInt();
			System.out.println("enter emp_name to update");
		    String emp_name=s.next();
			
			ps.setString(1, emp_name);
			ps.setInt(2, emp_id);
			
			int b= ps.executeUpdate();
			
			if(b==1) {
				System.out.println("employee name successfully update");
				
			}
			else {
				System.out.println("not found employee id");
			}
		}catch(SQLException e) {
			
		}
	}

}